#######################################

Aluno: João Pedro Vicente Ramalho
GRR: 20224169

#######################################

Apontamentos:

-> Para rodar o programa é preciso dar o seguinte comando: $python3 remove_ruidos.py <img_entrada>

-> Não há geração de imagem ao final do programa.